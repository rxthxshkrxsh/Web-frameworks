package com.example.ce4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ce4Application {

	public static void main(String[] args) {
		SpringApplication.run(Ce4Application.class, args);
	}

}
