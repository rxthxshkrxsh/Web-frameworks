package com.example.ce4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ce4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
