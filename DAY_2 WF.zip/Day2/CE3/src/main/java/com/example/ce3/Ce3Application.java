package com.example.ce3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ce3Application {

	public static void main(String[] args) {
		SpringApplication.run(Ce3Application.class, args);
	}

}
