package com.example.ce3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ce3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
