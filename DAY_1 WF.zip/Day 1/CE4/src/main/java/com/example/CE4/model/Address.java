package com.example.CE4.model;

public class Address {
    public int doorNo;
    public String streetName;

    public Address(int doorNo,String streetName)
    {
        this.doorNo=doorNo;
        this.streetName=streetName;
    }
}
