package com.example.CE5.model;

public class Student {
    public String studentName;
    public String message;

    public Student(String studentName,String message)
    {
        this.studentName=studentName;
        this.message=message;
    }
}
